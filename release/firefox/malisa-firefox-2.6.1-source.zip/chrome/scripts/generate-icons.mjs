import sharp from 'sharp';
import { mkdirSync, writeFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = join(__dirname, '..');
const src = join(root, 'assets', 'malisa-icon-source.png');
const outDir = join(root, 'icons');
const assetsDir = join(root, 'assets');

const BG = { r: 26, g: 26, b: 46, alpha: 1 };

const ICON16_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16">
  <defs>
    <radialGradient id="g" cx="50%" cy="42%" r="70%">
      <stop offset="0%" stop-color="#2d2a55"/>
      <stop offset="100%" stop-color="#1a1a2e"/>
    </radialGradient>
  </defs>
  <rect width="16" height="16" rx="4.5" fill="url(#g)"/>
  <circle cx="8" cy="7.5" r="5.2" fill="none" stroke="#6c63ff" stroke-width=".3" opacity=".4"/>
  <line x1="3.8" y1="5.5" x2="5.8" y2="6.8" stroke="#8b84ff" stroke-width=".3" opacity=".65"/>
  <line x1="10.2" y1="5.6" x2="12" y2="7.4" stroke="#8b84ff" stroke-width=".3" opacity=".65"/>
  <circle cx="3.8" cy="5.5" r=".4" fill="#b8b0ff"/>
  <circle cx="12" cy="7.4" r=".4" fill="#b8b0ff"/>
  <rect x="1.6" y="1.5" width="2.4" height="2.4" rx=".45" fill="#6c63ff" opacity=".9"/>
  <rect x="1.9" y="1.8" width="1.8" height="1.8" rx=".25" fill="none" stroke="#d4cfff" stroke-width=".25"/>
  <line x1="2.2" y1="2.5" x2="3.4" y2="2.5" stroke="#d4cfff" stroke-width=".25"/>
  <line x1="2.2" y1="3.1" x2="3.4" y2="3.1" stroke="#d4cfff" stroke-width=".25"/>
  <path fill="#6c63ff" opacity=".85" d="M12.2 1.6c.5 0 .9.4 1 .9.2.6-.1 1.2-.6 1.5-.3.2-.7.3-1 .2-.6-.1-1-.7-.9-1.3 0-.7.5-1.3 1.2-1.3z"/>
  <path fill="none" stroke="#d4cfff" stroke-width=".25" d="M12.5 2.1c-.2.5-.5.8-.9 1"/>
  <ellipse cx="6.1" cy="7.6" rx="2.3" ry="2.5" fill="#fff"/>
  <path fill="#6c63ff" d="M4.5 5.6c.2-.8.7-1.3 1.2-1.6.2-.45.6-.7 1-.7s.8.25 1 .7c.5.3 1 .8 1.2 1.6v2.5H4.5V5.6z"/>
  <ellipse cx="5.3" cy="7.4" rx=".5" ry=".32" fill="#1a1a2e"/>
  <ellipse cx="6.9" cy="7.4" rx=".5" ry=".32" fill="#1a1a2e"/>
  <path fill="none" stroke="#1a1a2e" stroke-width=".4" stroke-linecap="round" d="M5.7 8.6q.4.3.8 0"/>
  <circle cx="10.5" cy="8.8" r="1.35" fill="#6c63ff"/>
  <path fill="none" stroke="#fff" stroke-width=".32" d="M9.8 8.8h1.4M10.5 8.1v1.4"/>
  <text x="8" y="14.2" text-anchor="middle" font-family="system-ui,sans-serif" font-size="2.6" font-weight="700" fill="#d4cfff">AI</text>
</svg>`;

mkdirSync(outDir, { recursive: true });
mkdirSync(assetsDir, { recursive: true });
writeFileSync(join(assetsDir, 'icon16-template.svg'), ICON16_SVG);

async function renderFromSource(size) {
  const padding = size <= 48 ? 1 : 2;
  const inner = size - padding * 2;

  await sharp(src)
    .resize(inner, inner, { fit: 'contain', background: BG, kernel: sharp.kernel.lanczos3 })
    .sharpen({ sigma: size <= 48 ? 0.35 : 0.2, m1: 1, m2: 0.5 })
    .extend({ top: padding, bottom: padding, left: padding, right: padding, background: BG })
    .png({ compressionLevel: 9, palette: size <= 48, quality: 100, effort: 10 })
    .toFile(join(outDir, `icon${size}.png`));

  console.log(`icon${size}.png`);
}

async function renderTinyIcon() {
  await sharp(Buffer.from(ICON16_SVG))
    .resize(16, 16, { kernel: sharp.kernel.cubic })
    .png({ compressionLevel: 9, palette: true, effort: 10 })
    .toFile(join(outDir, 'icon16.png'));
  console.log('icon16.png (chip + brain + AI)');
}

await renderTinyIcon();
for (const size of [48, 128]) {
  await renderFromSource(size);
}

console.log(`Icons written to ${outDir}`);
